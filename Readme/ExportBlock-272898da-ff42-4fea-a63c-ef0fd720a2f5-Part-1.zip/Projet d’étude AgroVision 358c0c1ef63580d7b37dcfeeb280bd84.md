# Projet d’étude : AgroVision

---

## À propos

---

Application web proposant une solution numérique appliquée au secteur agricole, en lien avec les problématiques de suivi des cultures, de gestion des ressources et d'aide à la prise de décision.

---

## Table des matières

---

- [A propos](https://www.notion.so/Projet-d-tude-AgroVision-358c0c1ef63580d7b37dcfeeb280bd84?pvs=21)
- [Outils utilisés](https://www.notion.so/Projet-d-tude-AgroVision-358c0c1ef63580d7b37dcfeeb280bd84?pvs=21)
- [Utilisation](https://www.notion.so/Projet-d-tude-AgroVision-358c0c1ef63580d7b37dcfeeb280bd84?pvs=21)
- [Contribution](https://www.notion.so/Projet-d-tude-AgroVision-358c0c1ef63580d7b37dcfeeb280bd84?pvs=21)
- [Remerciement](https://www.notion.so/Projet-d-tude-AgroVision-358c0c1ef63580d7b37dcfeeb280bd84?pvs=21)

## Outils utilisés

---

→ [Table des matières](https://www.notion.so/Projet-d-tude-AgroVision-358c0c1ef63580d7b37dcfeeb280bd84?pvs=21)

La réalisation de ce projet nous a demandé de le diviser en divers étapes. Pour commencer, nous avons réaliser le frontend en html/css et brièvement en javascript. Nous avons fait ce choix d’outils car il s’agit des langages de frontend avec lesquelles nous sommes le plus à l’aise. De plus, cela permet bonne compatibilité avec le back en Flask, micro-framework pour Python.

Quant au backend, nous l’avons donc réalisé en Python, par l’utilisation du micro-framework Flask.  Ce choix ce justifie par sa simplicité et sa légèreté, comparé à Django qui impose certains choix. De plus Flask, s’intègre facilement à SQLAlchemy.

Pour SQLAlchemy, sa structure simplifie le code. En effet, SQLAlchemy permet de ne pas mélanger du SQL et du Python. De plus, SQLAlchemy simplifie le changement de système de gestion de base de données, permettant de passer facilement de SQLite à Postgresql. Ansi, SQLAlchemy nous a facilité le code ainsi que le déploiement de l’application.

Finalement pour le déploiement,

## Utilisation

---

→ [Table des matières](https://www.notion.so/Projet-d-tude-AgroVision-358c0c1ef63580d7b37dcfeeb280bd84?pvs=21)

L’application web se divise en plusieurs pages, chacune répondant aux demandes du client. 

La page d’accueil se présente ainsi : 

![image.png](image.png)

![image.png](image%201.png)

![image.png](image%202.png)

La page d’accueil sert à présenter les fonctionnalités disponible sur l’application web.

On peut retrouver l’accès à la fonctionnalité login via le bouton connexion. On peut aussi retrouver un bouton permettant d’accéder au tableau de bord. Finalement on retrouve une liste décrivant les fonctionnalités principales, et les données requis.  

En voulant accéder à la page du tableau de bord, le bouton nous redirige automatiquement vers la page de login. Ainsi, sans authentification, il n’est pas possible d’accéder au tableau de bord.

Pour s’authentifier, il est nécessaire de rentrer les identifiants suivants : 

[jean.dupont@agrovision.fr](mailto:jean.dupont@agrovision.fr)  dupont123

![image.png](image%203.png)

Une fois connecté celle-ci nous redirige vers le dashboard

![image.png](image%204.png)

![image.png](image%205.png)

![image.png](image%206.png)

Le dashboard intègre une fonctionnalité de filtre pour mieux se repérer. Le tableau de bord permet de visualiser les récentes alertes et observations reçus, ainsi que l’état des parcelles.

Il est aussi possible d’accéder à la page d’observations, d’alertes et de parcelles via le header.

![image.png](image%207.png)

Grâce à l’hébergement du site, il est possible d’ajouter une observation. Cette observation sera alors transmis au dashboard, mais aussi partagée aux autres utilisateurs.

![image.png](image%208.png)

Quant à la page d’alerte, celle-ci fonctionne via une API connecté à l’application web. Lors du lancement d’une nouvelle recherche, l’application envoie une requête à l’API, récupère les informations nécessaire et affiche une alerte si les seuils sont dépassés.

![image.png](image%209.png)

Finalement pour les parcelles, le processus est le même que la page d’observation.

## Contribution

---

→ [Table des matières](https://www.notion.so/Projet-d-tude-AgroVision-358c0c1ef63580d7b37dcfeeb280bd84?pvs=21)

Pour le bon déroulement du projet, nous avons analysé le projet, puis réfléchit et proposé les taches à réaliser. De ce faite nous avons, réalisé un schéma, à partir de l’outil Trello, suivant la méthode Kanban.

![image.png](image%2010.png)

il s’agit, globalement, des taches définies par l’équipe.

![image.png](image%2011.png)

Ramazan a contribué à la mise en place de la pipeline Git; ainsi que la page d’accueil, aidé de Robin.

Wakil a contribué à la création de la page de login; et la réalisation du MCD/MLD, aidé de Youcef.

Youcef a contribué à la création de la BDD, aidé par Robin; ainsi qu’à la réalisation du schéma d’architecture.

Robin a contribué à la création de la page d’accueil, aidé par Ramazan; et la création de la BDD, aidé par Youcef.

![image.png](image%2012.png)

Ramazan a contribué à la création de la page du dashboard.

Wakil a contribué à la création de la page de gestion des parcelles et cultures.

Youcef a terminé la création de la BDD, et a contribué à la réalisation du responsive.

Robin a contribué à la création de la page d’observation et suivi.

![image.png](image%2013.png)

Ramazan a terminé la page de dashboard, aidé de tout le groupe. De plus, il a corrigé et nettoyé le code, aidé par Robin et Wakil.

Wakil a réalisé le readme.md.

Youcef a terminé le responsive. Et a contribué au déploiement de la BDD sur le cloud, ainsi qu’à l’hébergement du site, aidé de Ramazan.

Robin a réalisé la page d’alerte.

![image.png](image%2014.png)

Wakil a terminé le readme.md

Le groupe a vérifié que la version finale fonctionne. Et a réalisé la vidéo.

![image.png](image%2015.png)

Avec plus de temps, nous aurions ajouté ces autres fonctionnalités. Finalement, ces fonctionnalités sont à prévoir pour une v2.

## Remerciement

---

→ [Table des matières](https://www.notion.so/Projet-d-tude-AgroVision-358c0c1ef63580d7b37dcfeeb280bd84?pvs=21)

Ramazan Akman, Wakil El jarrari, Youcef Guermouche et Robin Le Boedec, nous vous remercions pour ce projet ainsi que pour cette année.